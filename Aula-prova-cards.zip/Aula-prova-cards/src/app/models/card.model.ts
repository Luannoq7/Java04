export interface Card {
id: number | string;
titulo: string;
subtitulo?: string;
tag?: string;
clickButton: string;
}

