@Component({
  selector: 'app-card-item',
  standalone: true, // Adicione esta linha
  imports: [],
  templateUrl: './card-item.html',
  styleUrl: './card-item.css'
})
export class CardItemComponent {
}

