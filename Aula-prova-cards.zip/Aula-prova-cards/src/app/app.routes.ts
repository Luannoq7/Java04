import { Routes } from '@angular/router';
import { CardItemComponent } from './components/card-item/card-item';

export const routes: Routes = [
  {
  path: '',
  component: CardItemComponent

  }
];
