import { Component } from '@angular/core';
import { CommonModule } from '@angular/common'; // Para usar *ngFor ou @for
import { CardItemComponent } from './components/card-item/card-item'; // Importação aqui


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    CardItemComponent // Registre o componente aqui para poder usá-lo no HTML
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  // Sua lista de dados (que usa o card.model.ts) ficaria aqui
}
